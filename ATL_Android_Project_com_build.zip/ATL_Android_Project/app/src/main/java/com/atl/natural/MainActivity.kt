package com.atl.natural

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.atl.natural.data.AtlMenu
import com.atl.natural.data.AtlMenuGroup
import com.atl.natural.data.AtlMenuItem

private val AtlGreen = Color(0xFF174B3A)
private val AtlMint = Color(0xFFEAF2ED)
private val AtlBg = Color(0xFFF5F7F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CookieManager.getInstance().setAcceptCookie(true)
        setContent { AtlTheme { AtlRoot() } }
    }
}

@Composable
private fun AtlTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = AtlGreen,
            secondary = Color(0xFF4E806A),
            background = AtlBg,
            surface = Color.White
        ), content = content
    )
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AtlRoot() {
    val context = LocalContext.current
    var webView by remember { mutableStateOf<WebView?>(null) }
    var loading by remember { mutableStateOf(false) }
    var loadError by remember { mutableStateOf(false) }
    var currentUrl by remember { mutableStateOf(AtlMenu.BASE + "/") }
    var screen by remember { mutableStateOf("Início") }
    var drawerOpen by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()
    LaunchedEffect(drawerOpen) {
        if (drawerOpen) drawerState.open() else drawerState.close()
    }
    var aboutOpen by remember { mutableStateOf(false) }
    var expandedGroups by remember { mutableStateOf(setOf("Principal", "Financeiro", "Pedidos e vendas")) }

    fun navigate(url: String) {
        screen = "Portal"
        loadError = false
        currentUrl = url
        val host = Uri.parse(url).host.orEmpty()
        if (host == "ev.atlanticanatural.com.br") {
            webView?.loadUrl(url)
        } else {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        drawerOpen = false
    }

    BackHandler(enabled = drawerOpen || aboutOpen || (screen == "Portal" && webView?.canGoBack() == true)) {
        when {
            aboutOpen -> aboutOpen = false
            drawerOpen -> drawerOpen = false
            else -> webView?.goBack()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 340.dp)) {
                Column(Modifier.fillMaxWidth().background(AtlGreen).padding(20.dp)) {
                    Text("ATL", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Atlântica Natural", color = Color.White.copy(alpha = .85f))
                    Spacer(Modifier.height(12.dp))
                    Text("ESCRITÓRIO VIRTUAL", color = Color.White.copy(alpha = .7f), style = MaterialTheme.typography.labelSmall)
                }
                LazyColumn(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    items(AtlMenu.groups) { group ->
                        val expanded = group.title in expandedGroups
                        ListItem(
                            headlineContent = { Text(group.title, fontWeight = FontWeight.SemiBold) },
                            leadingContent = { Icon(Icons.Default.FolderOpen, null, tint = AtlGreen) },
                            trailingContent = { Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null) },
                            modifier = Modifier.clickable {
                                expandedGroups = if (expanded) expandedGroups - group.title else expandedGroups + group.title
                            }
                        )
                        if (expanded) group.items.forEach { item ->
                            NavigationDrawerItem(
                                label = { Text(item.title, style = MaterialTheme.typography.bodyMedium) },
                                selected = currentUrl == item.url,
                                onClick = { navigate(item.url) },
                                modifier = Modifier.padding(start = 18.dp, bottom = 2.dp),
                                icon = { Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(18.dp)) }
                            )
                        }
                    }
                    item {
                        HorizontalDivider(Modifier.padding(vertical = 8.dp))
                        NavigationDrawerItem(
                            label = { Text("Sobre") },
                            selected = aboutOpen,
                            onClick = { aboutOpen = true; drawerOpen = false },
                            icon = { Icon(Icons.Default.Info, null) }
                        )
                    }
                }
                Text("Desenvolvido por Thiago Araujo", modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                Text("Instagram: @oconsultormat", modifier = Modifier.padding(start = 18.dp, bottom = 16.dp), style = MaterialTheme.typography.labelSmall, color = AtlGreen)
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ATL", fontWeight = FontWeight.Bold)
                            Text("Atlântica Natural", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { drawerOpen = true }) { Icon(Icons.Default.Menu, "Abrir menu") }
                    },
                    actions = {
                        IconButton(onClick = { if (screen == "Portal") webView?.reload() else navigate(AtlMenu.BASE + "/") }) {
                            Icon(Icons.Default.Refresh, "Atualizar")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = screen == "Início", onClick = { screen = "Início"; aboutOpen = false }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                    NavigationBarItem(selected = screen == "Serviços", onClick = { screen = "Serviços"; drawerOpen = true }, icon = { Icon(Icons.Default.GridView, null) }, label = { Text("Serviços") })
                    NavigationBarItem(selected = screen == "Pedidos", onClick = { navigate(AtlMenu.BASE + "/pedidos") }, icon = { Icon(Icons.Default.ShoppingBag, null) }, label = { Text("Pedidos") })
                    NavigationBarItem(selected = screen == "Perfil", onClick = { navigate(AtlMenu.BASE + "/consultores/dados-pessoais") }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Perfil") })
                }
            },
            containerColor = AtlBg
        ) { padding ->
            when {
                aboutOpen -> AboutScreen(Modifier.padding(padding))
                screen == "Início" || screen == "Serviços" -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    onOpenMenu = { drawerOpen = true },
                    onNavigate = ::navigate,
                    onAbout = { aboutOpen = true }
                )
                else -> Box(Modifier.fillMaxSize().padding(padding)) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.databaseEnabled = true
                                settings.loadsImagesAutomatically = true
                                settings.allowFileAccess = false
                                settings.allowContentAccess = true
                                settings.javaScriptCanOpenWindowsAutomatically = false
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                                webChromeClient = WebChromeClient()
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                        val uri = request.url
                                        val host = uri.host.orEmpty()
                                        val allowed = uri.scheme == "https" && (host == "ev.atlanticanatural.com.br" || host.endsWith(".atlanticanatural.com.br"))
                                        if (allowed) return false
                                        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                        return true
                                    }
                                    override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                                        loading = true; loadError = false; if (url != null) currentUrl = url
                                    }
                                    override fun onPageFinished(view: WebView?, url: String?) { loading = false }
                                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                                        if (request?.isForMainFrame == true) { loading = false; loadError = true }
                                    }
                                }
                                webView = this
                                loadUrl(currentUrl)
                            }
                        },
                        update = { webView = it }
                    )
                    if (loading) CircularProgressIndicator(Modifier.align(Alignment.TopCenter).padding(12.dp), color = AtlGreen)
                    if (loadError) Card(Modifier.align(Alignment.Center).padding(24.dp)) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Não foi possível carregar o portal.")
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { loadError = false; webView?.reload() }) { Text("Tentar novamente") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onOpenMenu: () -> Unit,
    onNavigate: (String) -> Unit,
    onAbout: () -> Unit
) {
    val shortcuts = listOf(
        Triple("Financeiro", Icons.Default.AccountBalanceWallet, AtlMenu.BASE + "/financeiro/extrato"),
        Triple("Minha rede", Icons.Default.Groups, AtlMenu.BASE + "/unilevel"),
        Triple("Realizar pedido", Icons.Default.ShoppingCart, AtlMenu.BASE + "/pedidos/realizar"),
        Triple("ATL Solar", Icons.Default.WbSunny, AtlMenu.BASE + "/energia/minhas-vendas"),
        Triple("Seguros", Icons.Default.VerifiedUser, AtlMenu.BASE + "/atlseguros/meus-planos"),
        Triple("Divulgação", Icons.Default.Share, AtlMenu.BASE + "/gerador-feed")
    )
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = AtlGreen), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(22.dp)) {
                    Text("ESCRITÓRIO VIRTUAL", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Bem-vindo ao ATL", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("Sua plataforma Atlântica Natural em um só lugar.", color = Color.White.copy(alpha = .9f))
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { onNavigate(AtlMenu.BASE + "/") }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = AtlGreen)) {
                        Text("Abrir Escritório Virtual")
                        Spacer(Modifier.width(6.dp)); Icon(Icons.Default.ArrowForward, null)
                    }
                }
            }
        }
        item { Text("Acesso rápido", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(shortcuts.chunked(2)) { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { (title, icon, url) ->
                    Card(Modifier.weight(1f).clickable { onNavigate(url) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Icon(icon, null, tint = AtlGreen, modifier = Modifier.size(28.dp))
                            Text(title, fontWeight = FontWeight.SemiBold, color = AtlGreen)
                        }
                    }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth().clickable { onOpenMenu() }, colors = CardDefaults.cardColors(containerColor = AtlMint)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Apps, null, tint = AtlGreen)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text("Todos os serviços", fontWeight = FontWeight.Bold, color = AtlGreen); Text("Explore os módulos do portal", style = MaterialTheme.typography.bodySmall) }
                    Icon(Icons.Default.ChevronRight, null, tint = AtlGreen)
                }
            }
        }
        item {
            TextButton(onClick = onAbout) { Icon(Icons.Default.Info, null); Spacer(Modifier.width(6.dp)); Text("Sobre o ATL") }
        }
    }
}

@Composable
private fun AboutScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Surface(shape = RoundedCornerShape(24.dp), color = AtlGreen, modifier = Modifier.size(92.dp)) {
            Box(contentAlignment = Alignment.Center) { Text("ATL", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(20.dp))
        Text("ATL", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = AtlGreen)
        Text("Atlântica Natural", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        Text("Aplicativo de acesso ao Escritório Virtual Atlântica Natural.", color = Color.DarkGray)
        Spacer(Modifier.height(28.dp))
        HorizontalDivider()
        Spacer(Modifier.height(20.dp))
        Text("Desenvolvido por", style = MaterialTheme.typography.labelLarge, color = Color.Gray)
        Text("Thiago Araujo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Instagram: @oconsultormat", color = AtlGreen, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(20.dp))
        Text("Versão 1.0.0", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        Text("Este aplicativo é uma interface independente de acesso ao portal. Não representa declaração de propriedade, parceria ou endosso oficial pela Atlântica Natural.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
    }
}
