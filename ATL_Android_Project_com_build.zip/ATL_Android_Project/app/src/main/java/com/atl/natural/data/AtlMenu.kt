package com.atl.natural.data

data class AtlMenuItem(val title: String, val url: String)
data class AtlMenuGroup(val title: String, val items: List<AtlMenuItem>)

object AtlMenu {
    const val BASE = "https://ev.atlanticanatural.com.br"
    val groups = listOf(
        AtlMenuGroup("Principal", listOf(
            AtlMenuItem("Escritório", "$BASE/"),
            AtlMenuItem("Portal de Ingressos", "$BASE/ingresso/portal"),
            AtlMenuItem("ATL Finance", "$BASE/atlfinance/portal")
        )),
        AtlMenuGroup("Área do consultor", listOf(
            AtlMenuItem("Dados pessoais", "$BASE/consultores/dados-pessoais"),
            AtlMenuItem("Dados PJ", "$BASE/consultores/dados-pj"),
            AtlMenuItem("Senha financeira", "$BASE/consultores/senha-financeira"),
            AtlMenuItem("Dados bancários", "$BASE/consultores/dados-bancarios"),
            AtlMenuItem("Documentos", "$BASE/consultores/documentos"),
            AtlMenuItem("Dependentes", "$BASE/consultores/dependentes"),
            AtlMenuItem("Sucessores", "$BASE/consultores/sucessores"),
            AtlMenuItem("Meus vouchers", "$BASE/vouchers"),
            AtlMenuItem("Meus cupons", "$BASE/cupons"),
            AtlMenuItem("Meus ingressos", "$BASE/cupons/ingressos")
        )),
        AtlMenuGroup("Rede e Unilevel", listOf(
            AtlMenuItem("Cadastrar consultor", "$BASE/rede/cadastrar"),
            AtlMenuItem("Rede", "$BASE/unilevel"),
            AtlMenuItem("Indicados", "$BASE/rede/indicados"),
            AtlMenuItem("Relatório de ativos", "$BASE/unilevel/relatorio-ativos"),
            AtlMenuItem("Relatório de inativos", "$BASE/unilevel/relatorio-inativos"),
            AtlMenuItem("Relatório de novos", "$BASE/unilevel/relatorio-novos"),
            AtlMenuItem("Cadastros sem adesão", "$BASE/unilevel/relatorio-cadastros-sem-adesao"),
            AtlMenuItem("Qualificações", "$BASE/unilevel/relatorio-qualificacoes"),
            AtlMenuItem("Graduações", "$BASE/unilevel/relatorio-graduacoes"),
            AtlMenuItem("Relatório por níveis", "$BASE/unilevel/relatorio-por-niveis"),
            AtlMenuItem("Top cadastro", "$BASE/unilevel/relatorio-top-cadastro"),
            AtlMenuItem("Relatório Top Vendas", "$BASE/rede/relatorio-top-vendas"),
            AtlMenuItem("Top Cadastros", "$BASE/rede/top-cadastros")
        )),
        AtlMenuGroup("Clientes", listOf(
            AtlMenuItem("Cadastrar cliente", "$BASE/clientes/cadastrar"),
            AtlMenuItem("Clientes da minha loja", "$BASE/clientes")
        )),
        AtlMenuGroup("Seguros Auto", listOf(
            AtlMenuItem("Cadastrar", "$BASE/atlsegurosauto/cadastrar"),
            AtlMenuItem("Acessar", "$BASE/atlsegurosauto/acessar"),
            AtlMenuItem("Minhas apólices", "$BASE/atlsegurosauto/minhas-apolices")
        )),
        AtlMenuGroup("Financeiro", listOf(
            AtlMenuItem("Extrato", "$BASE/financeiro/extrato"),
            AtlMenuItem("Bônus mensal", "$BASE/financeiro/bonus-mensal"),
            AtlMenuItem("Transferência", "$BASE/financeiro/transferencia"),
            AtlMenuItem("Transferência para franquia", "$BASE/financeiro/transferencia-franquia"),
            AtlMenuItem("Minhas solicitações de saque", "$BASE/financeiro/saques")
        )),
        AtlMenuGroup("Pedidos e vendas", listOf(
            AtlMenuItem("Realizar pedido", "$BASE/pedidos/realizar"),
            AtlMenuItem("Comprar serviços", "$BASE/pedidos/comprar-servicos"),
            AtlMenuItem("Meus pedidos", "$BASE/pedidos"),
            AtlMenuItem("Minhas vendas online", "$BASE/pedidos/minhas-vendas-online")
        )),
        AtlMenuGroup("Energia e ATL Solar", listOf(
            AtlMenuItem("Nova assinatura solar", "$BASE/energia/nova-venda"),
            AtlMenuItem("Minhas assinaturas solares", "$BASE/energia/minhas-vendas"),
            AtlMenuItem("Clientes ATL Solar", "$BASE/solaratl/clientes"),
            AtlMenuItem("Acessar painel ATL Solar", "https://painelatlsolar.com.br/")
        )),
        AtlMenuGroup("ATL Seguros", listOf(
            AtlMenuItem("Contratar", "$BASE/atlseguros"),
            AtlMenuItem("Meus planos", "$BASE/atlseguros/meus-planos")
        )),
        AtlMenuGroup("Social e divulgação", listOf(
            AtlMenuItem("Quero ser um doador", "$BASE/social/quero-ser-um-doador"),
            AtlMenuItem("Doadores", "$BASE/social/doadores"),
            AtlMenuItem("Gráficos", "$BASE/graficos"),
            AtlMenuItem("Franquias", "$BASE/franquias"),
            AtlMenuItem("Feed", "$BASE/gerador-feed"),
            AtlMenuItem("Stories", "$BASE/gerador-stories"),
            AtlMenuItem("Biblioteca", "$BASE/biblioteca"),
            AtlMenuItem("Links de divulgação", "$BASE/produtos/links-divulgacao")
        )),
        AtlMenuGroup("Outros serviços", listOf(
            AtlMenuItem("ATL Academy", "$BASE/ia/academy-acesso"),
            AtlMenuItem("Clube de benefícios", "https://meuclubedevantagens.com.br/"),
            AtlMenuItem("Suporte", "$BASE/suporte"),
            AtlMenuItem("Sair do portal", "$BASE/home/logout")
        ))
    )
}
