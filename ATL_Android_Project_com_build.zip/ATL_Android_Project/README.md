# ATL — Aplicativo Android

Aplicativo Android híbrido para acesso ao Escritório Virtual Atlântica Natural.

## Recursos
- Interface nativa em Kotlin + Jetpack Compose.
- Início com atalhos rápidos.
- Menu lateral expansível com módulos e caminhos extraídos do arquivo MHT fornecido.
- Navegação inferior: Início, Serviços, Pedidos e Perfil.
- WebView integrada para o domínio `ev.atlanticanatural.com.br`.
- Cookies habilitados para manter a sessão web no dispositivo.
- Links externos abertos no navegador do aparelho.
- Tela Sobre com crédito: **Desenvolvido por Thiago Araujo — Instagram @oconsultormat**.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK 35.
- Gradle compatível com Android Gradle Plugin 8.7.3.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `ATL_Android_Project` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um dispositivo Android ou inicie um emulador.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Para gerar APK de distribuição, configure uma chave de assinatura em **Build > Generate Signed Bundle / APK**.

## Observações técnicas e limitações
- Os caminhos do menu foram extraídos do arquivo MHT disponibilizado na conversa. Alguns destinos podem exigir login, permissões ou condições específicas da conta.
- Os módulos de terceiros (por exemplo, ATL Solar e Clube de Benefícios) são abertos no navegador externo.
- A sessão web depende dos cookies e das políticas de autenticação do próprio portal.
- Uploads via seletor de arquivos, câmera, notificações push e downloads autenticados exigem implementação e testes adicionais conforme os fluxos reais do portal.
- O projeto é entregue como código-fonte Android Studio. Não foi possível confirmar uma compilação nem um APK assinado neste ambiente; compile e teste antes de distribuir.
- O ATL é uma interface independente de acesso e não deve ser apresentado como aplicativo oficial ou endossado pela Atlântica Natural sem autorização da empresa.
